# this needs to be used in settings -> downloads to set
# fcking dir fuck 
/opt/google/chrome/chrome --v=1  --enable-logging=stderr  --remote-debugging-port=23000  --user-data-dir=/tmp/ --profile-directory=DefaultZ
