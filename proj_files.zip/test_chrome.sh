
# ./test_chrome.sh "https://www.homes.com/property/0-outback-ridge-trail-jasper-ga-unit-10456301/fntllcceltpr8/"

#/opt/google/chrome/chrome  --user-data-dir=/tmp/ --profile-directory=Default "$1"
#/opt/google/chrome/chrome  --remote-debugging-port=23000  --user-data-dir=/tmp/ --profile-directory=Default "$1"

#window.location.assign("https://www.example.com");

#/opt/google/chrome/chrome  --remote-debugging-port=23000  --user-data-dir=/tmp/ --profile-directory=Default --app="data:text/html,<html><body><script>window.moveTo(10,10);window.resizeTo(300,300);window.location.assign(\"$1\");</script></body></html>"
/opt/google/chrome/chrome  --remote-debugging-port=9222  --user-data-dir=/tmp/ --profile-directory=Default --app="data:text/html,<html><body><script>window.moveTo(10,10);window.resizeTo(300,300);window.location.assign(\"$1\");</script></body></html>"
